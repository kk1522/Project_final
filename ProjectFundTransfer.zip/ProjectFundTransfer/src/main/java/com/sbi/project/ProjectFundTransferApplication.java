package com.sbi.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectFundTransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectFundTransferApplication.class, args);
	}

}
