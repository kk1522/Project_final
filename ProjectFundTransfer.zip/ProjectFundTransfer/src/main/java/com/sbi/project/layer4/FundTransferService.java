package com.sbi.project.layer4;

public interface FundTransferService {
	public void transferFund(int dAcc, int cAcc, int amount);
}
