package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Payee;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.PayeeRepository;
@Service
public class PayeeServiceImpl implements PayeeService {

	
	@Autowired
	PayeeRepository payeeRepo;
	
	@Autowired
	AccountRepository accRepo;
	
	@Override
	public void addPayeeService(Payee payeeObj, int targetAccount) {
		System.out.println("addPayeeService()");
		Payee pObj=new Payee();
		System.out.println("targetAcc"+targetAccount);
		Account aObj =accRepo.getAccount(targetAccount);
		pObj.setPayeeName(payeeObj.getPayeeName());
		pObj.setNickName(payeeObj.getNickName());
		pObj.setPayeeAccountNumber(payeeObj.getPayeeAccountNumber());
		pObj.setAccount(aObj);
		aObj.getPayee().add(pObj);
		//accRepo.setAccount(aObj);
		payeeRepo.addPayee(pObj);
	}

	@Override
	public void deletePayeeService(int payeeId) {
		payeeRepo.deletePayee(payeeId);

	}

	@Override
	public Payee findPayee(int payeeId) {
		
		return payeeRepo.findPayee(payeeId);
	}

	@Override
	public List<Payee> findAllPayee(int accountNumber) {

		return payeeRepo.findAllPayee(accountNumber);
	}

}
