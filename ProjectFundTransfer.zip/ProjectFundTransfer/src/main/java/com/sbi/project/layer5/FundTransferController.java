package com.sbi.project.layer5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer4.FundTransferService;

@CrossOrigin
@RestController
@RequestMapping("/transfer")
public class FundTransferController {

	@Autowired
	FundTransferService fTService;
	
	@PostMapping("/ownbank")
	public void transferfund(@RequestBody TransferDetailsDTO trfDetailsDTO) {
		fTService.transferFund(trfDetailsDTO.debitAccount, trfDetailsDTO.creditAccount, trfDetailsDTO.amount);
		
	}
	
}
