package com.sbi.project.layer5;

public class TransferDetailsDTO {

	public int debitAccount;
	public int creditAccount;
	public int amount;
}
