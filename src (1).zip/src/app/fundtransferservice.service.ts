import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TransferDetailsDTO } from './fundtransfer/TransferDetailsDTO';
import { Account } from './payee-menu/Account';

@Injectable({
  providedIn: 'root'
})
export class FundtransferserviceService {

  baseUrl:String="http://localhost:8080/account"
  constructor(private myHttp:HttpClient) { }

  getAccountService(accNumber:number) : Observable<Account>{
    return this.myHttp.get<Account>(this.baseUrl+"/get/"+accNumber);
  }
  setAccountService(account:Account) : Observable<string>{
    return this.myHttp.post<string>(this.baseUrl+"/setAccount",account);
  }

  transferAmount(trDetail:TransferDetailsDTO) : Observable<String>{
    return this.myHttp.post<string>("http://localhost:8080/transfer/ownbank",trDetail);
  }

  
}
