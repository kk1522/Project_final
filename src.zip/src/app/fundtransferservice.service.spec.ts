import { TestBed } from '@angular/core/testing';

import { FundtransferserviceService } from './fundtransferservice.service';

describe('FundtransferserviceService', () => {
  let service: FundtransferserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FundtransferserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
