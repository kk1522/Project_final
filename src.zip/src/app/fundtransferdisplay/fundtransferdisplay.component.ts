import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-fundtransferdisplay',
  templateUrl: './fundtransferdisplay.component.html',
  styleUrls: ['./fundtransferdisplay.component.css']
})
export class FundtransferdisplayComponent implements OnInit {

  msg:any;
  constructor(private route:ActivatedRoute) {
      this.route.params.subscribe(param=> this.msg=param['msg']);
   }

  ngOnInit(): void {
  }

}
