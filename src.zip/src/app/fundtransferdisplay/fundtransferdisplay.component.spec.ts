import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundtransferdisplayComponent } from './fundtransferdisplay.component';

describe('FundtransferdisplayComponent', () => {
  let component: FundtransferdisplayComponent;
  let fixture: ComponentFixture<FundtransferdisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FundtransferdisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundtransferdisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
