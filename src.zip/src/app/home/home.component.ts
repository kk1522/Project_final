import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  username:any="";
  balance:any="";
  showbalance:boolean=false;
  constructor(private router:Router) { 
    this.username=sessionStorage.getItem('name');
    this.balance=sessionStorage.getItem('balance');
  }
  ngOnInit(): void {
    
  }
  toggleBal(){
    this.showbalance=!this.showbalance;
    this.balance=sessionStorage.getItem('balance');
  }
  logout(){
    sessionStorage.clear();
    this.router.navigateByUrl('/login')
  }

}
