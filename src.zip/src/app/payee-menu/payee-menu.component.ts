import { ɵHttpInterceptingHandler } from '@angular/common/http';
import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { PayeeServiceService } from '../payee-service.service';
import { Account } from './Account';
import { Payee } from './Payee';
import { PayeeDTO } from './PayeeDTO';

@Component({
  selector: 'app-payee-menu',
  templateUrl: './payee-menu.component.html',
  styleUrls: ['./payee-menu.component.css']
})
export class PayeeMenuComponent implements OnInit {
  payeeType: String = "";
  show: boolean = false;
  v: boolean = false;
  a: boolean = false;
  d: boolean = false;
  msg: string = "";
  id: number = 0;
  user: any = sessionStorage.getItem('user');
  userAccount = Number(this.user);
  errorMsg: string = "";
  error: Boolean = false;
  cAcc: string = "";
  confirmAcc: number = 0;
  pAcc: string = "";
  existingPayee: boolean = false;


  constructor(private payeeServ: PayeeServiceService) {

  }
  menuIdentifier: string = "";
  payee: Payee = new Payee();

  payeeArray: Payee[] = [];

  accountName: string = "";
  //account: Account=new Account();

  ngOnInit(): void {

    this.getPayeebyAccount();

  }

  getPayeebyAccount() {
    this.payeeServ.getPayeeService(this.userAccount).subscribe(
      (data: Payee[]) => {
        this.payeeArray = data;
      }
    );


  }

  deletePayee(payeeIdDelete: number) {
    console.log("deletePayee()");
    this.payeeServ.deletePayeeService(payeeIdDelete).subscribe(
      (data: any) => {
        this.msg = data;
      }, (err) => {
        console.log(err);
      }
    );
      this.showDelete();
    alert("Payee deleted sucessfully");
    this.getPayeebyAccount();
  }

  payeeDTO: PayeeDTO = new PayeeDTO();

  addPayee() {
    console.log("addPayee called")
    this.payeeArray.forEach(element => {
      if (element.payeeAccountNumber == this.payee.payeeAccountNumber) {
        this.existingPayee = true;
      }
    });
    this.payee.payeeAccountNumber = Number(this.pAcc);
    // this.account.accountNumber=10001;
    if (this.payee.nickName != " " && this.payee.payeeAccountNumber != 0 && this.payee.payeeName != " " &&
      this.payee.payeeAccountNumber != this.userAccount&&!this.existingPayee) {
  
        this.payeeDTO.payeeToAdd = this.payee;
        this.payeeDTO.targetAccountNumber = this.userAccount;
        console.log("addPayee called" + this.payee.account.accountNumber);
        console.log(this.payee)
        this.payeeServ.addPayeeService(this.payeeDTO).subscribe(
          (data: any) => {
            this.msg = data;
          }
        );
        this.pAcc = "";
        this.cAcc = ""
        this.showAdd();
        alert(this.payee.nickName + " sucessfully added as payee");
        this.getPayeebyAccount();
        }
      else {
        alert("Fill the empty fields/Invalid account no/Existing Paayee");
      }
    }

    validateAcc(){
      this.confirmAcc = Number(this.cAcc);
      this.payee.payeeAccountNumber = Number(this.pAcc);
      if (this.payee.payeeAccountNumber != this.confirmAcc) {
        this.errorMsg = "Account Number does not match";
        this.error = true;
      }
      else {
        this.error = false;
      }
    }
    showView(){
      this.v = !this.v;
      this.a = false;
      this.d = false;
    }
    showAdd(){
      this.a = !this.a;
      this.d = false;
      this.v = false;
    }
    showDelete(){
      this.d = !this.d;
      this.a = false;
      this.v = false;
    }
    toggleIfsc(){
      console.log("toggle");
      console.log(this.payeeType);
      console.log(this.menuIdentifier);
      if (this.payeeType === "Own Bank Account") {
        this.show = false;
      }
      else if (this.payeeType === "Other Bank Account") {
        this.show = true;
      }

    }

  }
