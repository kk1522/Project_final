import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { iif } from 'rxjs';
import { AppComponent } from '../app.component';
import { FundtransferserviceService } from '../fundtransferservice.service';
import { Account } from '../payee-menu/Account';
import { Payee } from '../payee-menu/Payee';
import { PayeeServiceService } from '../payee-service.service';
import { TransferDetailsDTO } from './TransferDetailsDTO';


@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  constructor(private payeeServ: PayeeServiceService, private fundSer: FundtransferserviceService, private router: Router) {
    this.getPayeebyAccount();
    this.getAccountDetailsUser();
  }

  data: any;
  user: any = sessionStorage.getItem('user');
  username: number = Number(this.user);
  payeeArray: Payee[] = [];
  payeeObj: Payee = new Payee();
  pAccNum: number = 0;
  payeeAccount: Account = new Account();
  selfAccount: Account = new Account();
  transferAmountString = "";
  transferAmount: number=0;
  msg: string = "";
  trfDetails: TransferDetailsDTO = new TransferDetailsDTO();
  transferMsg:string="";

  getPayeebyAccount() {
    this.payeeServ.getPayeeService(this.username).subscribe(
      (data: Payee[]) => {
        this.payeeArray = data;
      }
    );
  }

  setSelfAccount() {
    this.fundSer.setAccountService(this.selfAccount).subscribe(
      (data: any) => {
        this.msg = data;
      },
      (err) => {
        console.log(err);
      }
    );

  }
  excecuteTransfer() {
    if (this.pAccNum != 0 && this.transferAmount != 0) {
      if (this.selfAccount.balance > this.transferAmount) {



        this.getAccountDetails();
        this.transferFunds();
        this.setPayeeAccount();
        this.setSelfAccount();
        sessionStorage.setItem('balance', String(this.selfAccount.balance));
        alert("Transfer sucessfull - current balace is " + this.selfAccount.balance);



      } else {
        alert("insufficient balance");
      }

    } else {
      alert("Fill the blank fields");
    }

  }
  getAccountDetails() {
    this.fundSer.getAccountService(this.pAccNum).subscribe(
      (data: Account) => {
        this.payeeAccount = data;
      }
    );
  }

  getAccountDetailsUser() {
    this.fundSer.getAccountService(this.username).subscribe(
      (data: Account) => {
        this.selfAccount = data;
      }
    );
  }

  setPayeeAccount() {
    this.fundSer.setAccountService(this.payeeAccount).subscribe(
      (data: any) => {
        this.msg = data;
      },
      (err) => {
        console.log(err);
      }
    );

    //alert("Transfer sucessfull - current balace is "+this.selfAccount.balance);
  }
  transferFunds() {
    // this.getAccountDetails();
    if (this.selfAccount.balance < this.transferAmount) {
      alert("insufficient balance current balance:" + this.selfAccount.balance);
    } else {
      this.payeeAccount.balance = this.payeeAccount.balance + this.transferAmount;
      this.selfAccount.balance = this.selfAccount.balance - this.transferAmount;
    }
  }
  transferFundsbySpring() {

    if (this.pAccNum != 0 && this.transferAmount != 0) {
      if (this.selfAccount.balance > this.transferAmount) {
        this.trfDetails.debitAccount = this.username;
        this.trfDetails.creditAccount = this.pAccNum;
        this.trfDetails.amount = this.transferAmount;
        this.fundSer.transferAmount(this.trfDetails).subscribe(
          (data: any) => {
            this.msg = data;
          },
          (err) => {
            console.log(err);
          }
        );
        this.transferMsg= "Rs. "+this.transferAmount+" is sucessfully transferred to Account Number: "+this.pAccNum;
        this.router.navigateByUrl('/fdisplay/'+this.transferMsg);

      } else {
        alert("insufficient balance");
      }

    } else {
      alert("Fill the blank fields");
    }
  }

  ngOnInit(): void {

  }
}
